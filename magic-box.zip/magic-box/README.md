# Magic box

A Pen created on CodePen.

Original URL: [https://codepen.io/R-HEDDAD/pen/zYLrqoO](https://codepen.io/R-HEDDAD/pen/zYLrqoO).

