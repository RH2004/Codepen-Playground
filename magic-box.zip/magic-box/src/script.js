const box = document.getElementById('box');
let x = 0;
let y = 0;
let directionX = 1;
let directionY = 1;
 
setInterval(() => {
  x += directionX;
  y += directionY;
  box.style.left = x + 'px';
  box.style.top = y + 'px';

  if (x + box.offsetWidth >= window.innerWidth || x <= 0) {
    directionX = -directionX;
    let r = Math.floor(Math.random() * 256); // generate a random number between 0 and 255
    let g = Math.floor(Math.random() * 256); // generate a random number between 0 and 255
    let b = Math.floor(Math.random() * 256); // generate a random number between 0 and 255
    box.style.backgroundColor = `rgb(${r}, ${g}, ${b})`; // set the background color of the box element
  }

  if (y + box.offsetHeight >= window.innerHeight || y <= 0) {
    directionY = -directionY;
    let r = Math.floor(Math.random() * 256); // generate a random number between 0 and 255
    let g = Math.floor(Math.random() * 256); // generate a random number between 0 and 255
    let b = Math.floor(Math.random() * 256); // generate a random number between 0 and 255
    box.style.color = `rgb(${r}, ${g}, ${b})`; // set the text color of the box element
  }
}, 10);
