
let display = document.getElementById('display');
let buttons = document.getElementsByClassName('number');
let operators = document.getElementsByClassName('operator');
let firstNumber = '';
let secondNumber = '';
let operator = '';
let result = '';

for (let i = 0; i < buttons.length; i++) {
buttons[i].addEventListener('click', function() {
if (operator === '') {
firstNumber += this.value;
display.textContent = firstNumber;
} else {
secondNumber += this.value;
display.textContent = secondNumber;
}
});
}

for (let i = 0; i < operators.length; i++) {
operators[i].addEventListener('click', function() {
if (this.value === '=') {
switch(operator) {
case '+':
result = Number(firstNumber) + Number(secondNumber);
break;
case '-':
result = Number(firstNumber) - Number(secondNumber);
break;
case '*':
result = Number(firstNumber) * Number(secondNumber);
break;
case '/':
result = Number(firstNumber) / Number(secondNumber);
break;
default:
result = '';
}
display.textContent = result;
firstNumber = '';
secondNumber = '';
operator = '';
} else {
operator = this.value;
}
});
}